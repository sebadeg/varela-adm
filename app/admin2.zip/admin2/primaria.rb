ActiveAdmin.register_page "Primaria" do

  menu priority: 50, label: "Primaria"

  content do
    render partial: 'primaria'
  end

end